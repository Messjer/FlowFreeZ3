#include <iostream>
#include "generator.h"

using namespace std;

int main() {
    string dir = "../../testcase/set0/";
    Generator g;

    //generate 10 files, with file name 0.txt, 1.txt, ...
    for (int i = 0; i < 10; i++) {
        g.setName(dir + char(48 + i) + ".txt");
        g.write();
    }
    return 0;
}
