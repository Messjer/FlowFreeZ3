#include "generator.h"

using namespace std;

void Generator::write() {
    ofstream fout(fName);
    // generate a table, maximum size is 20
    int table[20][20] = {};
    // size of the board in range [5, 11), can be modified to gain speicific test cases
    int N = random(6) + 5;
    // terminals in range[N / 1.5, N / 1.5 + N / 5), can be modified
    int M = random(N / 5) + N / 1.5;

    int cnt = 0;

    // generate terminals
    while (cnt != 2 * M) {
        int x = random(N);
        int y = random(N);
        // if this is picked as terminal, pick another one
        if (table[x][y]) continue;
        cnt++;
        // mark this point with its label, the first pair is 1, the second pair 2 ...
        table[x][y] = (cnt + 1) / 2;
    }
    // blocks in range[1, 1 + N / 2), can be modified
    int K = random(N / 2) + 1;
    cnt = 0;

    // generate blocks
    while (cnt != K) {
        // the upper left corner of the block
        int x = random(N);
        int y = random(N);
        int h = random((N - 1 - y)) + 1; // height
        int w = random((N - 1 - x)) + 1; // width

        bool valid = true;

        // check if this block is placed on empty grids
        for (int i = x; i < x + w && valid; i++)
            for (int j = y; j < y + h && valid; j++)
                valid = valid && !table[i][j];

        // only add the block if it is placed on empty grids
        if (valid) {
            for (int i = x; i < x + w; i++)
                for (int j = y; j < y + h; j++)
                    table[i][j] = -1;
            cnt++;
        }
    }
    // output format
    // an integer N
    // N * N matrix
    // 0 represents empty, -1 are blocks, others are terminals
    fout <<N <<endl;
    for (int i = 0; i < N; i++, fout <<endl)
        for (int j = 0; j < N; j++)
            fout <<table[i][j] <<' ';
}
