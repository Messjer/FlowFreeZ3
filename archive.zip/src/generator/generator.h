#ifndef GENERATOR_H
#define GENERATOR_H
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <ctime>
class Generator {
private:
    std::string fName;
    int random(int a) {
        if (!a) return 0;
        return rand() % a;
    }
public:
    Generator(std::string name = "input.txt"): fName(name) {
        srand(time(NULL));
    }
    void setName(std::string name) {
        fName = name;
    }
    void write();
};
#endif /* GENERATOR_H */
