//
// Created by Hong Man Hou on 25/5/2017.
//

#ifndef SRC_BOARD_H
#define SRC_BOARD_H
#include <set>
#include <iostream>

// A class holding the information of a grid board
class Board {
private:
    // maximum size of the board allowed
    const static int MAXBOARD = 20;
public:
    // the size of the board
    int n;

    // the layout of the board
    int table[MAXBOARD][MAXBOARD];
    bool isTerminal[MAXBOARD][MAXBOARD];

    // contructor takes an input file
    Board(std::string fName);

    // an inner class representing a grid
    class Grid {
    public:
        const int x, y, color;
        Grid(int x, int y, int color): x(x), y(y), color(color) {}
        friend bool operator < (const Grid &lhs, const Grid &rhs);
    };

    // set of terminals
    std::set<Grid> term;

    // override the << operator to provide easy output
    friend std::ostream& operator << (std::ostream &out, const Board b);
};

#endif //SRC_BOARD_H
