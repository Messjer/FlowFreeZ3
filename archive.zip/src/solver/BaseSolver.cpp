//
// Created by Hong Man Hou on 25/5/2017.
//

#include "BaseSolver.h"
#include <fstream>
#include <iostream>
#include <sstream>
using namespace std;

// this function write the output board into a file
void BaseSolver::write(string fName) {
    assert(output != NULL);
    ofstream fout(fName);
    fout <<*output;
    cout <<"Output Successfully written in " <<fName <<endl;
}