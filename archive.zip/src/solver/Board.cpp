//
// Created by Hong Man Hou on 25/5/2017.
//

#include "Board.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <cassert>

using namespace std;

// this operator is implemented for std::set<>
bool operator < (const Board::Grid &lhs, const Board::Grid &rhs) {
    // lexicographical order suffices
    return (lhs.x == rhs.x ? lhs.y < rhs.y : lhs.x < rhs.x);
}

// constructor from input file
Board::Board(string fName) {
    ifstream fin(fName);
    fin >> n;

    // only non empty board is accepted
    assert(n != 0);

    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++) {
            int color;
            fin >>color;

            // if this is a terminal, add it to the set
            if (color != 0 && color != -1) {
                Grid g(i, j, color);
                term.insert(g);
            }

            isTerminal[i][j] = (color != 0 && color != -1);
            table[i][j] = color;
        }

    // validate input format
    int cnt[20] = {};
    try {
        assert(term.size() % 2 == 0);
    } catch (string e) {
        cerr <<"Input format not valid! Terminals must come in pairs!" <<endl;
        cerr <<e <<endl;
        exit(0x123);
    }

    // terminals come in pair
    // and are labelled from 1 to color_cnt
    int color_cnt = term.size() / 2;
    for (auto it = term.begin(); it != term.end(); it++)
        cnt[it -> color]++;
    for (int i = 1; i <= color_cnt; i++) {
        try {
            assert(cnt[i] == 2);
        } catch (string e) {
            cerr <<"Input format not valid! Terminals must come in pairs!" <<endl;
            cerr <<e <<endl;
            exit(0x123);
        }
    }
}

std::ostream& operator << (std::ostream &out, const Board b) {
    // a representation of the board
    // first line n is the size of the board
    // the other nxn entries are either 0, -1, or a number from 1 to color_cnt
    // -1 stands for block, 0 for empty space
    // other numbers are the filled grids. If appended with a *, it means it is a terminal
    out <<b.n <<endl;
    for (int i = 0; i < b.n; i++, out <<endl)
        for (int j = 0; j < b.n; j++)
            out <<b.table[i][j] <<(b.isTerminal[i][j] ? "*" : "") <<' ';
    return out;
}
