//
// Created by Hong Man Hou on 25/5/2017.
//

#ifndef SRC_Z3SOLVER_H
#define SRC_Z3SOLVER_H
#include "BaseSolver.h"
#include "z3++.h"

class Z3Solver : public BaseSolver {
private:
    // add routing constraints
    void addRoutingConstraint(int x, int y);

    // 0 <= color[x][y] <= #of colors
    void addColorConstraint(int x, int y);

    // wrapper for accessing color[x][y]
    z3::expr at(int x, int y);

    // return the # of nearby grids which is the same color with color[x][y]
    z3::expr countNear(const z3::expr &a, int x, int y);

    // casts boolean expression to int
    z3::expr toInt(const z3::expr &a);

    // count the number of matched terminals
    // i.e. f(1) + f(2) + ... + f(#color)
    z3::expr count(const z3::func_decl &f);

    // count the nubmer of grids used
    z3::expr countGrid();

    // store pointers for easy access
    // should be extremely careful using these pointers!
    z3::expr_vector *col;
    z3::func_decl *rout;
    z3::context *c;
    z3::optimize *solv;

    Z3Solver(const BaseSolver &other);
    Z3Solver& operator = (const BaseSolver & other);
public:
    Z3Solver(std::string fName): BaseSolver(fName) {}

    // override the base class solve()
    void solve();
};

#endif //SRC_Z3SOLVER_H
