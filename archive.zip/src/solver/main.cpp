#include "Z3Solver.h"
#include <iostream>
#include <ctime>
#include <fstream>

using namespace std;

int main() {
    // some directories
    string dir = "../../testcase/set";
    string outdir = "../../testcase/set";

    cout <<"Please enter which testcase to process, e.g. \"0\"" <<endl;
    cout <<"Note that, in the test set there should be a valid input 0.txt for the program to function properly" <<endl;
    cout <<">> ";
    int target; cin >>target;

    dir = dir + char(target + 48) + "/";
    outdir = outdir + char(target + 48) + "/";
    BaseSolver *s = new Z3Solver(dir + "0.txt");

    // numer of tests are 10
    int T = 10;
    cout <<"Do you want to process all testcases?(Y/n)" <<endl;
    char c;
    cin >>c;

    if (c == 'Y') {
        cout <<"Please enter the limit on the board size ..." <<endl;
        cout <<"e.g. if input = 10. Testcases with size > 10 will be ignored ..." <<endl;
        cout <<"This is used to safeguard the program, otherwise it may run indeterminately long" <<endl;
        cout <<">> ";
        int t;
        cin >>t;

        ofstream fout(outdir + "stats.csv");
        fout <<"Board size, Number of terminals, Number of matched pairs, Number of grid used, used time (s)" <<endl;
        for (int i = 0; i < T; i++) {
            int start = clock();
            cout <<"Test " <<i <<"..." <<endl;
            s->resetInput(dir + char(i + 48) + ".txt");

            if (s->getBoard() -> n > t) {
                cout <<i <<".txt is abandoned due to safeguard purpose" <<endl;
                fout <<s->getBoard()->n <<", " <<s->getColorCnt() <<", " <<"NAN, NAN, NAN" <<endl;
                continue;
            }

            s->solve();
            s->write(outdir + char(i + 48) + ".out");

            double elapsed = (clock() - start)/ (double) CLOCKS_PER_SEC;
            fout <<s->getBoard()->n <<", " <<s->getColorCnt() <<", "
                 <<s->getMatched() <<", " <<s->getRouteLen() <<", " <<elapsed <<endl;
            cout <<"Used time " <<elapsed <<" s" <<endl;
            cout <<endl;
        }
    } else {
        cout << "Please input the number of testcase you wish to run ... (e.g. 0)" << endl;
        cout << "Note: large testcases may run extremely slowly ... " << endl;
        int q;
        cout <<">> ";
        cin >> q;

        int start = clock();

        cout <<"Test " <<q <<"..." <<endl;
        s->resetInput(dir + char(q + 48) + ".txt");

        s->solve();
        s->write(outdir + char(q + 48) + ".out");

        double elapsed = (clock() - start)/ (double) CLOCKS_PER_SEC;
        cout <<"Used time " <<elapsed <<" s" <<endl;
        cout <<endl;
    }
    return 0;
}
