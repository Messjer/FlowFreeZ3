//
// Created by Hong Man Hou on 25/5/2017.
// This is an interface class
// When different engines are applied
// user can implement their own solver

#ifndef SRC_BASESOLVER_H
#define SRC_BASESOLVER_H
#include "Board.h"
#include <cassert>

// This is a solver class
// it is abstract and require the solve() method to be implemented
class BaseSolver {
protected:
    // b is the input, output is the output
    // pointers are stored to make the solve lightweight
    Board *b, *output;

    // matched: is the number of successfully matched terminals
    // routelen: the number of routing grids used
    // colorCnt: total number of terminals
    int matched, routeLen, colorCnt;

    // maximum pair of terminals allowed is 20
    const static int MAXCOLOR = 20;
private:
    // do not allow copying solvers to avoid pointer issues
    BaseSolver(const BaseSolver &other);
    BaseSolver& operator = (const BaseSolver & other);
public:
    BaseSolver(std::string fName) {
        b = new Board(fName);
        colorCnt = b -> term.size() / 2;
        output = NULL;
    }

    // call this function to solve the problem
    virtual void solve() = 0;

    // write output to a file fName
    void write(std::string fName);

    // read input from fName
    void resetInput(std::string fName) {
        // delete the original board
        assert(b != NULL);
        delete b;
        b = NULL;

        // create a new board
        b = new Board(fName);
        colorCnt = b -> term.size() / 2;
        if (output != NULL) {
            delete output;
            output = NULL;
        }
    }

    int getMatched() { assert(output != NULL); return matched; }
    int getRouteLen() { assert(output != NULL); return routeLen; }
    int getColorCnt() { assert(b != NULL); return colorCnt; }

    // this function return a pointer to the input grid
    const Board* getBoard() {return b;}

    // This function returns the board layout object
    // it should be called after calling solve()
    Board * Solution() {
        assert(output != NULL);
        Board * sol = new Board(*output);
        return sol;
    }

    ~BaseSolver() {
        // free all allocated memory
        assert(b != NULL);
        delete b;
        b = NULL;
        if (output != NULL) {
            delete output;
            output = NULL;
        }
    }
};


#endif //SRC_GRIDSOLVER_H
