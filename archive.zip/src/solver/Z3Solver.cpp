//
// Created by Hong Man Hou on 25/5/2017.
//

#include "Z3Solver.h"
#include <iostream>

using namespace std;
using namespace z3;

expr Z3Solver::at(int x, int y) {
    // wrapper for accessing color[x][y]
    if (0 <= x && x < b -> n && 0 <= y && y < b -> n)
        return col -> operator[](x * b -> n + y);
    else return c -> int_val(0);
}

expr Z3Solver::toInt(const z3::expr &a) {
    // casts boolean expression to int
    return ite(a, c -> int_val(1), c -> int_val(0));
}

expr Z3Solver::countNear(const z3::expr &a, int x, int y) {
    // return the # of nearby grids which is the same color with color[x][y]
    expr ex = toInt(a == at(x + 1, y)) + toInt(a == at(x, y + 1));
    ex = ex + toInt(a == at(x - 1, y));
    ex = ex + toInt(a == at(x, y - 1));
    return ex;
}

expr Z3Solver::count(const func_decl &f) {
    // count the number of matched terminals
    // i.e. f(1) + f(2) + ... + f(#color)
    expr ex = toInt(rout -> operator()(1));
    for (int i = 2; i <= colorCnt; i++)
        ex = ex + toInt(f(i));
    return ex;
}

expr Z3Solver::countGrid() {
    // count the nubmer of grids used
    // i counted the number of obstacles (-1) also
    // because obstacles does not make a difference
    // in the minimizing process
    expr ex = toInt(at(0, 0) != 0);
    for (int i = 0; i < b -> n; i++)
        for (int j = 0; j < b -> n; j++) {
            // 0, 0 is already counted, so I check if(i || j)
            if (i || j)
                ex = ex + toInt(at(i, j) != 0);
        }
    return ex;
}

void Z3Solver::addRoutingConstraint(int x, int y) {
    // if it is terminal, and the terminal is routed, then the number of neighbors
    // with the same color is 1, otherwise, if the grid is used, the number of neighbors
    // with the same color is 2
    // e.g. the following is valid
    // 3
    // 1* 1 1*
    // -1 -1 -1
    // 0 0 0
    // while this is not valid
    // 3
    // 1* 1 1*
    // -1 1 -1
    // 0 0 0
    if (b -> isTerminal[x][y])
        solv -> add(implies(at(x, y) != 0 && rout -> operator()(at(x, y)), countNear(at(x, y), x, y) == 1));
    else
        solv -> add(implies(at(x, y) != 0 && rout -> operator()(at(x, y)), countNear(at(x, y), x, y) == 2));
}

void Z3Solver::addColorConstraint(int x, int y) {
    // every empty grid can be used as a routing grid or stay empty
    if (b -> table[x][y] == 0)
        solv -> add(at(x, y) >= 0 && at(x, y) <= colorCnt);
    else {
        // otherwise, the grid should stay to be a blcok
        // or a terminal
        solv->add(at(x, y) == b->table[x][y]);
    }
}

void Z3Solver::solve() {
    // delete the original result
    if (output != NULL) {
        delete output;
        output = NULL;
    }

    // check that input is valid
    assert(b != NULL);
    try {
        assert(!(b->term.empty()));
    } catch (string e) {
        cerr <<e <<endl;
        cerr <<"No terminals found, no need to solve" <<endl;
        exit(0x154);
    }

    // create a new result
    output = new Board(*b);

    cout << "Now Solving ... " <<endl <<*b << endl;

    // create some z3 containers
    context cxt;

    // color is a matrix, each from -1, 0, ...,  colorCnt
    // representing the variable grids
    expr_vector color(cxt);

    // routed is a function recording whether each color is successfully routed
    z3::sort I = cxt.int_sort(), B = cxt.bool_sort();
    func_decl routed = z3::function("routed", I, B);

    // create an optimizer
    optimize s(cxt);

    // pointers are stored to avoid passing the objects to the helper functions
    // e.g. at(int x, int y)
    // however, these pointers should be extremely carefully handled
    // as the objects may be invalid outside solve() scope
    col = &color; rout = &routed;
    solv = &s; c = &cxt;

    // NxN matrix of variables representing the colors of grid
    for (unsigned i = 0; i < b->n; ++i)
        for (unsigned j = 0; j < b->n; ++j) {
            // label for the variable is color_i_j
            stringstream c_name;
            c_name << "color_" << i << '_' << j;

            // create a new variable
            color.push_back(cxt.int_const(c_name.str().c_str()));
        }

    // add some constraints to the solution
    // these constraints are not enough to make every solution valid
    // With only these, constraints, z3 may produce some invalid layout.
    // see testcase/setBuggy/.
    // However, after making the optimization(minimizing the routing girds)
    // the output is indeed valid
    // For more information, see the documentation
    for (unsigned i = 0; i < b->n; ++i)
        for (unsigned j = 0; j < b->n; ++j) {
            addColorConstraint(i, j);
            addRoutingConstraint(i, j);
        }

    // we need to optimize two expression

    // first is to maximize the number of successfully matched pairs
    optimize::handle h1 = s.maximize(count(routed));

    // second is to minimize the number of grids used
    // note that this optimization is needed to make the solution valid
    // see testcase/setBuggy/. to see results without this constraints
    // and documentation for details
    optimize::handle h2 = s.minimize(countGrid());

    // this piece of program output the formulation sent to the solver
    // which can be useful for debugging
    /* cout <<"Show config?(Y/n)" <<endl;
    char input;
    cin >>input;
    if (input == 'Y')
        cout <<s <<endl; */

    cout <<"Solution process start, please wait patiently as this may take indeterminate time if input is large ... " <<endl;
    cout <<"Also feel free to kill the process if it does take too long ..." <<endl;

    // use z3 to solve
    s.check();

    // get the results and decode it
    model m = s.get_model();
    cout <<"Solution found!" <<endl;

    // number of matched pairs in the solution
    matched = m.eval(count(routed)).get_numeral_int();

    // mark whether each pair is successfully routed in the solution
    bool routedResult[MAXCOLOR + 1] = {};
    for (int i = 1; i <= colorCnt; i++)
        routedResult[i] = m.eval(routed(i)).bool_value() != -1;

    routeLen = 0;
    for (int i = 0; i < b -> n; i++)
        for (int j = 0; j < b -> n; j++) {
            output->table[i][j] = m.eval(at(i, j)).get_numeral_int();
            if (output -> table[i][j] != 0 && output -> table[i][j] != -1
                && routedResult[output -> table[i][j]])
                routeLen++;
            }

    cout <<*output <<endl;
    cout <<"#Successfully matched pairs = " <<matched <<endl;
    cout <<"#grids used = " <<routeLen <<endl;

    // Nullify the pointers to prevent them from escaping the function scope
    c = NULL; solv = NULL;
    col = NULL; rout = NULL;
}
