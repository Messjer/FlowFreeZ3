# /set8
This is a the devil's test case, large and dense set.  
*Recommended limit for this suit is 13.*  
*I run for more than 2 hours and the 15x15 did not terminate yet*.
