# /set3
This is a small board, dense terminals test set.
*Recommended limit for this suit is 20.*
