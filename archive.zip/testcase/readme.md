# /set0
This directory is where generator put its generated testcases.
It already contains some testcases along with their results.
This is a dense (more terminals) and small board test set.
*Recommended limit for this suit is 20.*
# /set1
This is a small board, more obstacles test set.
*Recommended limit for this suit is 10.*
# /set2
This is a small board, less obstacles test set.
*Recommended limit for this suit is 9.*
# /set3
This is a small board, dense terminals test set.
*Recommended limit for this suit is 20.*
# /set4
This is a larger board, 1-3 terminals test set.
*Recommended limit for this suit is 12.*
# /set5
This is a larger board, 1-3 terminals test set.
*Recommended limit for this suit is 12.*
# /set6
This is a general test set.
*Recommended limit for this suit is 12.*
# /set7
This is a general test set.
*Recommended limit for this suit is 13.*
# /set8
This is a the devil's test case, large and dense set.  
*Recommended limit for this suit is 13.*  
*I run for more than 2 hours and the 15x15 did not terminate yet*.
# /setBuggy
This is a set of test case establishing some buggy case that are fixed in Z3Solver.
For more information consult doc.
