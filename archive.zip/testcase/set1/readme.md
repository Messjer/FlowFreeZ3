# /set1
This is a small board, more obstacles test set.
*Recommended limit for this suit is 10.*
