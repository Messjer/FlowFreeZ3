# /set0
This directory is where generator put its generated testcases.
It already contains some testcases along with their results.
This is a dense (more terminals) and small board test set.
*Recommended limit for this suit is 20.*
