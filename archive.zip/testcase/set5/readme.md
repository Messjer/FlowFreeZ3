# /set5
This is a larger board, 1-3 terminals test set.
*Recommended limit for this suit is 12.*
