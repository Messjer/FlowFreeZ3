# /set2
This is a small board, less obstacles test set.
*Recommended limit for this suit is 9.*
