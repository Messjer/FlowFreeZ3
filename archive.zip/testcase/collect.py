stats = ""
readme = ""
for i in xrange(9):
    readme += open("set" + str(i) + "/readme.md", "r").read()
    stats += "set" + str(i) + "\n"
    stats += open("set" + str(i) + "/stats.csv", "r").read()
readme += open("setBuggy/readme.md", "r").read()
statsFout = open("stats_all.csv", "w")
readmeFout = open("readme.md", "w")
statsFout.write(stats)
readmeFout.write(readme)
