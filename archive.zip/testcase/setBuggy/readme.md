# /setBuggy
This is a set of test case establishing some buggy case that are fixed in Z3Solver.
For more information consult doc.
